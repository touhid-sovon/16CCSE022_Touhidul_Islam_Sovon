package chainofresponsibility;

public class Biochemistry_and_Biotechnology implements Demo {
	private Demo nextsubject;

	@Override
	public void setNext(Demo nextsubject) {
		// TODO Auto-generated method stub
		this.nextsubject=nextsubject;
	}

	@Override
	public void ServiceSupport(Student student) {
		// TODO Auto-generated method stub
		if ( student.marks.get("Biology") >=6 )
		{
			System.out.println("Biochemistry and Biotechnology");
		}
		nextsubject.ServiceSupport(student);
		
	}
}
