package chainofresponsibility;

public class Botany implements Demo {
	private Demo nextsubject;

	@Override
	public void setNext(Demo nextsubject) {
		// TODO Auto-generated method stub
		this.nextsubject=nextsubject;
	}

	@Override
	public void ServiceSupport(Student student) {
		// TODO Auto-generated method stub
		if ( student.marks.get("Biology") >=6)
		{
			System.out.println("Biology");
		}
		nextsubject.ServiceSupport(student);
		
	}
	
	
	
}
