package chainofresponsibility;

public class CSE implements Demo {
	private Demo nextsubject;

	@Override
	public void setNext(Demo nextsubject) {
		// TODO Auto-generated method stub
		this.nextsubject=nextsubject;
	}

	@Override
	public void ServiceSupport(Student student) {
		// TODO Auto-generated method stub
		if ( student.marks.get("Mathematics") >=6 || student.marks.get("Physics")>=6)
		{
			System.out.println("CSE");
		}
		nextsubject.ServiceSupport(student);
		
	}
	
	

}
