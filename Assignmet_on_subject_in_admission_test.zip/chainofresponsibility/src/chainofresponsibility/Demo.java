package chainofresponsibility;



public interface Demo {
	public  void setNext(Demo nextsubject);
	public void ServiceSupport(Student student);

}
