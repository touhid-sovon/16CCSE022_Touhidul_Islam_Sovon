package chainofresponsibility;

public class MATH implements Demo{
   private Demo nextsubject;
	@Override
	public void setNext(Demo nextsubject) {
		// TODO Auto-generated method stub
		this.nextsubject=nextsubject;
	}

	@Override
	public void ServiceSupport(Student student) {
		// TODO Auto-generated method stub
	 if(student.marks.get("Mathematics")>=6) System.out.println("Mathematics");
	 nextsubject.ServiceSupport(student);
	}
	
	

}
