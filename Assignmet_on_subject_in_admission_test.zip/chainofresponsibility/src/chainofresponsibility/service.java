package chainofresponsibility;


import java.util.Hashtable;


public class service {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Demo cse = new CSE();
		Demo math = new MATH();
		Demo bio = new Biochemistry_and_Biotechnology();
		Demo botany = new Botany();
		Demo chemistry = new Chemistry();
		Demo costal = new Coastal_states_and_degestar_management();
		Demo geologymining = new Geology_and_Mining();
		Demo physics = new Physic();
		Demo soil = new soil_and_environmental_sciences();
		Demo statistics = new Statistics();
		cse.setNext(math);
		math.setNext(bio);
		bio.setNext(botany);
		botany.setNext(chemistry);
		chemistry.setNext(costal);
		costal.setNext(geologymining);
		geologymining.setNext(physics);
		physics.setNext(soil);
		soil.setNext(statistics);		
		Student student = new Student();
		System.out.println("########### Student Take ############\n");
		cse.ServiceSupport(student);
		System.out.println("\n");
		System.out.println("-------->Subject---------->");
	}

	

}
